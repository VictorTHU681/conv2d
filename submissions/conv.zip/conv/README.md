# conv2d on Kunpeng SME — 鲲鹏 HPC 挑战赛 S2 CONV 赛题

FP32 二维 valid 卷积 `conv2d(in, H, W, k, KH, KW, out)` 的 SME（FMOPA）实现。结果与参考实现逐位一致
（校验 1e-5 绝对误差，低于输出量级的 1 ulp，因此必须保持与参考实现完全相同的 fma 累加链），按 GFLOPS 计分。

## 运行

```bash
bash run.sh    # 编译 + 四个用例（题面判题口径：OMP_NUM_THREADS=38 numactl -N 1）
```

`run.sh` 在 CPU 节点旁探测到纯内存节点（HBM，无 CPU、1～32 GB、距离 ≤ 70）时会加
`--preferred=<node>`，让基准数据（四例合计 < 600 MB）落入 HBM；放不下自动回落本地
DDR，探测不到则不加参数（即题面原命令）。`CONV_HBM=0` 可关闭。资源仍为单一 NUMA
节点的 38 个 CPU，不改变算法与结果。

或手动：

```bash
gcc -O3 -march=armv9-a+sme+sve2 -fopenmp bench_conv.c conv2d.c -o conv2d_test -lm   # 或题面的 gcc -O3 ...（文件内 pragma 打开 SME）
OMP_NUM_THREADS=38 numactl -N 1 ./conv2d_test 4096 6144 39 39 1
```

运行期用 HWCAP2 检测 SME；硬件或编译器不支持时自动回退 SVE/标量通用实现（任意合法尺寸均正确）。

## 核心思路

- FMOPA 外积对每个 ZA 元素恰是一次 fma。把卷积映射成外积序列，并保证每个输出元素的累加顺序与参考实现
  （kernel 行主序）完全一致 → 逐位精确。所有实现分支（滚动 / 经典 / SVE / 标量）都满足该性质。
- **滚动形态**（KH ≥ 16 且条带可行时启用，结构性条件，与具体用例尺寸无关）：tile 列 ↔ 输出行残差
  (s+c) mod KH，每列一条独立 fma 链，链满（KH 步）时 mova 切片直接落出连续输出，步数 = KW（X 方向零浪费）。
  残差按 KH 二进制分解成 16×1 对 / 单 16 / 8×2 / 4×4 组；余数残差折进 fmopa 旁并发的索引 fmla 链
  （每步 1 条 ld1rqw + 若干 fmla，链数按分解结构自动选 1/3/4），消掉低利用率的余数组。
- **经典形态**（其余形状）：tile 行 ↔ 输出列（stride 4），tile 列 ↔ 4×4 kernel 偏移，步数 (KH+3)(KW+3)；
  输入行去交织成 4 个平面驻留 L2 环形缓冲，a 向量用对齐载入 + `ext` 生成；整个 pass 的 Y 循环在一段汇编里，
  DRAM 预取、下一组的 ld4w 切片构建、已完成输出行的回写作为块组末尾的附加工作与 fmopa 交错。
  边界行（Y=0/1/KH+1/KH+2 只有少数列在干活）从 fmopa 循环移出，由并发的索引 fmla 半步完成。
- 滚动条带按 **8 个 kernel 高度周期**分块处理，保存 ZA 和 FMLA 的累加状态，下一块接续原来的 FMA 链，
  避免重复预热计算。线程先轮转处理本线程的相邻条带以复用输入；空闲后通过 CAS 接手其他条带的剩余行块，
  减少慢线程拖尾。状态只在本次调用内传递，每次调用重置进度。
- 每次调用都完整执行 kernel 打包，不缓存系数内容。使用 SVE gather 构造连续 R 向量，同一次调用中相同的
  完整 16 残差系数表共用一份；默认由主线程重建。线程绑核取自继承的亲和掩码（兼容 numactl/taskset），
  自有线程池调用间自旋（等价 OMP_WAIT_POLICY=ACTIVE）；经典形态保留原来的 pass 调度与回写策略。

## 文件

- `conv2d.c` 实现（单文件，含 SME/SVE/标量三级回退）；`bench_conv.c` 官方基准（未修改）；`run.sh` 编译 + 四例。
- 开发库另有 `tools/test_conv.c`（与参考四重循环逐位比较的泛化测试，固定边界用例 + 随机尺寸）、
  `tools/fbench.c`（快速判题口径 bench）、`tools/drv.c`（分相计时驱动）。
- `docs/v54.md` 与 `results/v54/` 记录性能瓶颈、被淘汰的实验及最终验收。`submissions/conv.zip` 为正式包；
  `conv_nf3.zip` 为三链对照，`conv_diag.zip` 为诊断包。两个带 `_zva` 的旧包仅为历史实验，不代表当前实现。

## 环境变量（默认即最优，仅用于实验/回退）

`CONV_ROLL=0` 强制经典形态；`CONV_POOL=0` 回退 OpenMP 并行区；`CONV_BR=0` 关边界行方案；
`CONV_SP`/`CONV_STORE`/`CONV_PFL2` 等微调项见 `conv2d.c` 的 `read_knobs()`；`CONV_NO_SME=1` 强制通用实现。
`CONV_PROFILE=1` 输出分相计时（stderr）。
