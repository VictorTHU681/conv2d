# Local K5 scalar-tail-unroll candidate

Source SHA256: 0136da05ea4658fb5792412e95baaec0e38ff299b176e5de681f228bca88da93
The published v62/v63 K5 copy-interleave and output-prefetch kernel is retained;
only its 0..2-scalar tail loop is replaced by bounded direct loads and stores.
The one or two accessed floats, coefficient construction, FMA order and logical
input/output mapping are unchanged. Other K5 assembly stays unchanged.
There is no runtime experiment knob or new result cache.

Original build: gcc -O3 bench_conv.c conv2d.c -o conv2d_test -lm -fopenmp
Original benchmark and existing run scripts are unchanged. run.sh retains
optional static-topology HBM placement. DDR/HBM are reported separately.
conv.zip is the normal candidate; conv_nf3.zip is a three-chain control;
conv_diag.zip contains probes and is diagnostic-only.
This isolated archive is for local acceptance, not a published release.
External concurrent callers, unchecked allocation failures and other SVL values
remain outside the validated scope; no blanket safety/compliance claim is made.
